from fastapi import FastAPI

from app.core.config import get_settings
from app.core.exceptions import register_exception_handlers
from app.core.logging import configure_logging, get_logger

settings = get_settings()
configure_logging(settings.ENVIRONMENT)
logger = get_logger(__name__)


def create_app() -> FastAPI:
    app = FastAPI(title="AI DevPulse API", version="0.1.0")
    register_exception_handlers(app)

    @app.on_event("startup")
    async def on_startup() -> None:
        logger.info("app_startup", environment=settings.ENVIRONMENT)

    @app.get("/health")
    async def health() -> dict:
        return {"status": "ok"}

    # Phase 5 will add: from app.api.v1.router import api_router; app.include_router(api_router, prefix="/api/v1")

    return app


app = create_app()
